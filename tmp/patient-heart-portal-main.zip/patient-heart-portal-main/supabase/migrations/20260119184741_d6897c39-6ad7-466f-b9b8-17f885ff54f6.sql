-- Create appointment types table
CREATE TABLE public.appointment_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  duration_minutes INTEGER NOT NULL DEFAULT 30,
  color TEXT DEFAULT '#10b981',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create appointments table
CREATE TABLE public.appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  appointment_type_id UUID REFERENCES public.appointment_types(id) NOT NULL,
  date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'confirmed', 'cancelled', 'completed', 'no_show')),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create available slots table (defines clinic working hours)
CREATE TABLE public.available_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create blocked dates table (holidays, vacations, etc)
CREATE TABLE public.blocked_dates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.appointment_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.available_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.blocked_dates ENABLE ROW LEVEL SECURITY;

-- RLS Policies for appointment_types (everyone can read)
CREATE POLICY "Anyone can view appointment types"
  ON public.appointment_types FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage appointment types"
  ON public.appointment_types FOR ALL
  USING (public.is_admin(auth.uid()));

-- RLS Policies for appointments
CREATE POLICY "Users can view their own appointments"
  ON public.appointments FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own appointments"
  ON public.appointments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own appointments"
  ON public.appointments FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all appointments"
  ON public.appointments FOR SELECT
  USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage all appointments"
  ON public.appointments FOR ALL
  USING (public.is_admin(auth.uid()));

-- RLS Policies for available_slots (everyone can read)
CREATE POLICY "Anyone can view available slots"
  ON public.available_slots FOR SELECT
  USING (is_active = true);

CREATE POLICY "Admins can manage available slots"
  ON public.available_slots FOR ALL
  USING (public.is_admin(auth.uid()));

-- RLS Policies for blocked_dates (everyone can read)
CREATE POLICY "Anyone can view blocked dates"
  ON public.blocked_dates FOR SELECT
  USING (true);

CREATE POLICY "Admins can manage blocked dates"
  ON public.blocked_dates FOR ALL
  USING (public.is_admin(auth.uid()));

-- Create trigger for appointments updated_at
CREATE TRIGGER update_appointments_updated_at
  BEFORE UPDATE ON public.appointments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default appointment types
INSERT INTO public.appointment_types (name, description, duration_minutes, color) VALUES
  ('Consulta Inicial', 'Primeira avaliação para transplante capilar', 60, '#3b82f6'),
  ('Consulta de Retorno', 'Acompanhamento pós-procedimento', 30, '#10b981'),
  ('Avaliação Pré-operatória', 'Exames e preparação para o procedimento', 45, '#8b5cf6'),
  ('Procedimento', 'Realização do transplante capilar', 480, '#f59e0b');

-- Insert default available slots (Monday to Friday, 8am to 6pm)
INSERT INTO public.available_slots (day_of_week, start_time, end_time) VALUES
  (1, '08:00', '12:00'),
  (1, '14:00', '18:00'),
  (2, '08:00', '12:00'),
  (2, '14:00', '18:00'),
  (3, '08:00', '12:00'),
  (3, '14:00', '18:00'),
  (4, '08:00', '12:00'),
  (4, '14:00', '18:00'),
  (5, '08:00', '12:00'),
  (5, '14:00', '18:00'),
  (6, '08:00', '12:00');