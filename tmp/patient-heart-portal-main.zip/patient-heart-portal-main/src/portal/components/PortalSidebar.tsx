import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { usePortalAuth, AppRole } from '../contexts/PortalAuthContext';
import { ThemeToggle } from '@/components/ThemeToggle';
import {
  Home, Calendar, FileText, Settings, LogOut, ChevronDown, ChevronRight,
  Menu, X, Users, DollarSign, Package, MessageSquare, Star, BarChart3, Heart,
  ClipboardList, Megaphone, Truck, AlertTriangle, Clock, UserPlus, Building2,
  Stethoscope, FileSearch, Video, Newspaper
} from 'lucide-react';

interface NavItem {
  id: string;
  title: string;
  icon: React.ElementType;
  path?: string;
  roles: AppRole[];
  children?: NavItem[];
}

const navItems: NavItem[] = [
  { id: 'home', title: 'Início', icon: Home, path: '/portal', roles: ['admin', 'doctor', 'reception', 'financial', 'inventory', 'patient'] },
  
  // Patient menu items
  { id: 'my-appointments', title: 'Meus Agendamentos', icon: Calendar, path: '/portal/appointments', roles: ['patient'] },
  { id: 'my-records', title: 'Meus Documentos', icon: FileText, path: '/portal/my-records', roles: ['patient'] },
  { id: 'orientations', title: 'Orientações', icon: ClipboardList, path: '/portal/orientations', roles: ['patient'] },
  { id: 'news', title: 'Notícias', icon: Newspaper, path: '/portal/news', roles: ['patient'] },

  // Scheduling
  {
    id: 'scheduling',
    title: 'Agenda',
    icon: Calendar,
    roles: ['admin', 'doctor', 'reception'],
    children: [
      { id: 'schedule', title: 'Ver Agenda', icon: Calendar, path: '/portal/schedule', roles: ['admin', 'doctor', 'reception'] },
      { id: 'new-appointment', title: 'Novo Agendamento', icon: UserPlus, path: '/portal/appointments/new', roles: ['admin', 'reception'] },
      { id: 'waiting-room', title: 'Sala de Espera', icon: Clock, path: '/portal/waiting-room', roles: ['admin', 'reception'] },
      { id: 'rooms', title: 'Salas', icon: Building2, path: '/portal/rooms', roles: ['admin'] },
    ],
  },

  // Medical
  {
    id: 'medical',
    title: 'Prontuário',
    icon: Stethoscope,
    roles: ['admin', 'doctor'],
    children: [
      { id: 'patients', title: 'Pacientes', icon: Users, path: '/portal/patients', roles: ['admin', 'doctor'] },
      { id: 'medical-records', title: 'Prontuários', icon: FileSearch, path: '/portal/medical-records', roles: ['admin', 'doctor'] },
      { id: 'templates', title: 'Modelos', icon: FileText, path: '/portal/templates', roles: ['admin', 'doctor'] },
      { id: 'teleconsultation', title: 'Teleconsulta', icon: Video, path: '/portal/teleconsultation', roles: ['admin', 'doctor'] },
    ],
  },

  // Financial
  {
    id: 'financial',
    title: 'Financeiro',
    icon: DollarSign,
    roles: ['admin', 'financial'],
    children: [
      { id: 'payments', title: 'Pagamentos', icon: DollarSign, path: '/portal/payments', roles: ['admin', 'financial'] },
      { id: 'invoices', title: 'Notas Fiscais', icon: FileText, path: '/portal/invoices', roles: ['admin', 'financial'] },
      { id: 'reports-financial', title: 'Relatórios', icon: BarChart3, path: '/portal/reports/financial', roles: ['admin', 'financial'] },
    ],
  },

  // Inventory
  {
    id: 'inventory',
    title: 'Estoque',
    icon: Package,
    roles: ['admin', 'inventory'],
    children: [
      { id: 'items', title: 'Itens', icon: Package, path: '/portal/inventory/items', roles: ['admin', 'inventory'] },
      { id: 'movements', title: 'Movimentações', icon: AlertTriangle, path: '/portal/inventory/movements', roles: ['admin', 'inventory'] },
      { id: 'suppliers', title: 'Fornecedores', icon: Truck, path: '/portal/inventory/suppliers', roles: ['admin', 'inventory'] },
    ],
  },

  // Communication
  {
    id: 'communication',
    title: 'Comunicação',
    icon: MessageSquare,
    roles: ['admin', 'reception'],
    children: [
      { id: 'whatsapp', title: 'WhatsApp', icon: MessageSquare, path: '/portal/whatsapp', roles: ['admin', 'reception'] },
      { id: 'campaigns', title: 'Campanhas', icon: Megaphone, path: '/portal/campaigns', roles: ['admin'] },
    ],
  },

  // Surveys
  {
    id: 'surveys',
    title: 'Pesquisas',
    icon: Star,
    roles: ['admin', 'doctor'],
    children: [
      { id: 'nps', title: 'NPS', icon: Star, path: '/portal/nps', roles: ['admin', 'doctor'] },
      { id: 'survey-list', title: 'Pesquisas', icon: ClipboardList, path: '/portal/surveys', roles: ['admin'] },
    ],
  },

  // Reports
  { id: 'reports', title: 'Relatórios', icon: BarChart3, path: '/portal/reports', roles: ['admin', 'doctor', 'financial'] },

  // Admin
  {
    id: 'admin',
    title: 'Administração',
    icon: Settings,
    roles: ['admin'],
    children: [
      { id: 'users', title: 'Usuários', icon: Users, path: '/portal/admin/users', roles: ['admin'] },
      { id: 'settings-admin', title: 'Configurações', icon: Settings, path: '/portal/admin/settings', roles: ['admin'] },
    ],
  },
];

export function PortalSidebar({ children }: { children: React.ReactNode }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [openItems, setOpenItems] = useState<string[]>(['scheduling']);
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = usePortalAuth();

  const handleLogout = async () => {
    await logout();
    navigate('/portal/landing');
  };

  const hasAccess = (roles: AppRole[]) => {
    if (!user) return false;
    return user.roles.some(role => roles.includes(role));
  };

  const filteredNavItems = navItems.filter(item => hasAccess(item.roles));

  const toggleItem = (id: string) => {
    setOpenItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const NavItemComponent = ({ item, depth = 0 }: { item: NavItem; depth?: number }) => {
    const isActive = item.path === location.pathname;
    const hasChildren = item.children && item.children.length > 0;
    const isOpen = openItems.includes(item.id);
    const filteredChildren = item.children?.filter(child => hasAccess(child.roles));

    if (hasChildren && filteredChildren && filteredChildren.length > 0) {
      return (
        <Collapsible open={isOpen} onOpenChange={() => toggleItem(item.id)}>
          <CollapsibleTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                "w-full justify-start gap-3",
                depth > 0 && "pl-8"
              )}
            >
              <item.icon className="h-5 w-5" />
              {!isCollapsed && (
                <>
                  <span className="flex-1 text-left">{item.title}</span>
                  {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </>
              )}
            </Button>
          </CollapsibleTrigger>
          <CollapsibleContent>
            {filteredChildren.map(child => (
              <NavItemComponent key={child.id} item={child} depth={depth + 1} />
            ))}
          </CollapsibleContent>
        </Collapsible>
      );
    }

    return (
      <Button
        variant={isActive ? "secondary" : "ghost"}
        className={cn(
          "w-full justify-start gap-3",
          depth > 0 && "pl-8",
          isActive && "bg-primary/10 text-primary"
        )}
        onClick={() => {
          if (item.path) {
            navigate(item.path);
            setIsMobileOpen(false);
          }
        }}
      >
        <item.icon className="h-5 w-5" />
        {!isCollapsed && <span>{item.title}</span>}
      </Button>
    );
  };

  const sidebarContent = (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
          <Heart className="h-6 w-6 text-primary-foreground" />
        </div>
        {!isCollapsed && (
          <div>
            <h1 className="font-bold text-lg">Portal Neo Folic</h1>
            <p className="text-xs text-muted-foreground">Clínica de Transplante Capilar</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 px-2 py-4">
        <div className="space-y-1">
          {filteredNavItems.map(item => (
            <NavItemComponent key={item.id} item={item} />
          ))}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t space-y-2">
        <div className="flex items-center justify-between mb-2">
          <ThemeToggle />
          {!isCollapsed && (
            <span className="text-sm text-muted-foreground truncate max-w-[120px]">
              {user?.full_name}
            </span>
          )}
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start gap-3"
          onClick={() => {
            navigate('/portal/settings');
            setIsMobileOpen(false);
          }}
        >
          <Settings className="h-5 w-5" />
          {!isCollapsed && <span>Configurações</span>}
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-destructive hover:text-destructive"
          onClick={handleLogout}
        >
          <LogOut className="h-5 w-5" />
          {!isCollapsed && <span>Sair</span>}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Mobile Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 lg:hidden"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        {isMobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
      </Button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed lg:sticky top-0 left-0 z-40 h-screen bg-card border-r transition-all duration-300",
          isCollapsed ? "w-16" : "w-64",
          isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {sidebarContent}
        
        {/* Collapse Toggle - Desktop */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute -right-3 top-20 h-6 w-6 rounded-full border bg-background hidden lg:flex"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          {isCollapsed ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3 rotate-90" />}
        </Button>
      </aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 min-h-screen transition-all duration-300",
        "lg:pl-0"
      )}>
        {children}
      </main>
    </div>
  );
}
