import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ThemeToggle } from '@/components/ThemeToggle';
import { 
  Heart, Calendar, FileText, Shield, Star, ArrowRight, 
  CheckCircle2, Clock, Users, Award 
} from 'lucide-react';

const features = [
  {
    icon: Calendar,
    title: 'Agendamento Online',
    description: 'Agende suas consultas e procedimentos de forma rápida e prática, 24 horas por dia.',
  },
  {
    icon: FileText,
    title: 'Histórico Médico',
    description: 'Acesse seu prontuário, exames e documentos médicos a qualquer momento.',
  },
  {
    icon: Shield,
    title: 'Orientações Personalizadas',
    description: 'Receba orientações pré e pós procedimento diretamente no seu portal.',
  },
  {
    icon: Star,
    title: 'Acompanhamento',
    description: 'Acompanhe sua evolução com fotos e relatórios do seu tratamento.',
  },
];

const stats = [
  { icon: Users, value: '+5.000', label: 'Pacientes Atendidos' },
  { icon: Award, value: '15+', label: 'Anos de Experiência' },
  { icon: CheckCircle2, value: '98%', label: 'Satisfação' },
  { icon: Clock, value: '24/7', label: 'Suporte Online' },
];

const testimonials = [
  'Excelente atendimento e resultados incríveis!',
  'Equipe altamente qualificada e atenciosa.',
  'Processo de agendamento muito prático.',
  'Satisfação de 98% dos pacientes',
];

export default function PortalLanding() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Heart className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-xl">Portal Neo Folic</h1>
              <p className="text-xs text-muted-foreground">Clínica de Transplante Capilar</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Link to="/portal/login">
              <Button variant="ghost">Entrar</Button>
            </Link>
            <Link to="/portal/register">
              <Button>Cadastrar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-primary mx-auto mb-8 flex items-center justify-center">
            <Heart className="h-10 w-10 text-primary-foreground" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Bem-vindo ao Portal <br />
            <span className="text-primary">Neo Folic</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
            Gerencie suas consultas, acompanhe seu tratamento e tenha acesso ao seu 
            histórico médico de forma simples e segura.
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/portal/register">
              <Button size="lg" className="gap-2">
                Começar Agora
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Link to="/portal/login">
              <Button size="lg" variant="outline">
                Já tenho conta
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-primary/5">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                <p className="text-3xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">
            Tudo que você precisa em um só lugar
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <Card key={feature.title} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center">
                    <feature.icon className="h-7 w-7 text-primary" />
                  </div>
                  <h4 className="font-semibold text-lg mb-2">{feature.title}</h4>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 bg-muted">
        <div className="container mx-auto">
          <h3 className="text-3xl font-bold text-center mb-12">O que dizem nossos pacientes</h3>
          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {testimonials.slice(0, 3).map((testimonial, index) => (
              <Card key={index} className="bg-background">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground italic">"{testimonial}"</p>
                </CardContent>
              </Card>
            ))}
            <div className="bg-gradient-to-br from-primary to-primary/80 rounded-3xl p-8 text-primary-foreground">
              <Star className="h-12 w-12 mb-4" />
              <p className="text-5xl font-bold mb-2">98%</p>
              <p className="text-xl mb-4">de satisfação dos pacientes</p>
              <p className="opacity-90">
                Nossos resultados falam por si. Confie em quem entende de transplante capilar.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-primary-foreground py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-4">Pronto para começar?</h3>
          <p className="text-xl opacity-90 mb-8">
            Crie sua conta gratuitamente e tenha acesso a todos os recursos do portal.
          </p>
          <Link to="/portal/register">
            <Button size="lg" variant="secondary" className="gap-2">
              Criar minha conta
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t">
        <div className="container mx-auto text-center text-muted-foreground">
          <p>© 2024 Neo Folic - Clínica de Transplante Capilar. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}
