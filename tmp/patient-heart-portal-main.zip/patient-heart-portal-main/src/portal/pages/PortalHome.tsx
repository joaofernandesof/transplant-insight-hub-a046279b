import React from 'react';
import { usePortalAuth } from '../contexts/PortalAuthContext';
import PatientDashboard from './dashboards/PatientDashboard';
import AdminDashboard from './dashboards/AdminDashboard';

export default function PortalHome() {
  const { user } = usePortalAuth();

  if (!user) return null;

  // Show appropriate dashboard based on primary role
  if (user.roles.includes('admin')) {
    return <AdminDashboard />;
  }

  if (user.roles.includes('doctor')) {
    return <AdminDashboard />;
  }

  if (user.roles.includes('reception')) {
    return <AdminDashboard />;
  }

  if (user.roles.includes('financial')) {
    return <AdminDashboard />;
  }

  if (user.roles.includes('inventory')) {
    return <AdminDashboard />;
  }

  // Default to patient dashboard
  return <PatientDashboard />;
}
