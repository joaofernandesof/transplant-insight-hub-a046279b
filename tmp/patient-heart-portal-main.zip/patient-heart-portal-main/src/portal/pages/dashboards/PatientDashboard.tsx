import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, FileText, Video, MessageSquare, Clock, Bell, ArrowRight, Newspaper, ClipboardList } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePortalAuth } from '../../contexts/PortalAuthContext';

export default function PatientDashboard() {
  const { user } = usePortalAuth();
  const navigate = useNavigate();

  const quickActions = [
    { icon: Calendar, label: 'Agendar Consulta', path: '/portal/appointments/new', color: 'bg-blue-500' },
    { icon: FileText, label: 'Meus Documentos', path: '/portal/my-records', color: 'bg-green-500' },
    { icon: ClipboardList, label: 'Orientações', path: '/portal/orientations', color: 'bg-purple-500' },
    { icon: Newspaper, label: 'Notícias', path: '/portal/news', color: 'bg-orange-500' },
  ];

  const upcomingAppointments = [
    { date: '25/01/2026', time: '10:00', type: 'Consulta de Retorno', doctor: 'Dr. Silva' },
  ];

  const notifications = [
    { id: 1, message: 'Seu próximo agendamento é em 5 dias', type: 'info' },
    { id: 2, message: 'Novas orientações pós-procedimento disponíveis', type: 'alert' },
  ];

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-6 text-primary-foreground">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold">
              {user?.full_name?.charAt(0) || 'P'}
            </span>
          </div>
          <div>
            <h1 className="text-2xl font-bold mb-1">
              Olá, {user?.full_name?.split(' ')[0]}!
            </h1>
            <p className="opacity-90">Bem-vindo ao seu Portal Neo Folic</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Button
            key={action.label}
            variant="outline"
            className="h-auto py-6 flex flex-col items-center gap-3 hover:border-primary"
            onClick={() => navigate(action.path)}
          >
            <div className={`w-12 h-12 ${action.color} rounded-full flex items-center justify-center`}>
              <action.icon className="h-6 w-6 text-white" />
            </div>
            <span className="text-sm font-medium">{action.label}</span>
          </Button>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Próximos Agendamentos
            </CardTitle>
            <CardDescription>Suas consultas agendadas</CardDescription>
          </CardHeader>
          <CardContent>
            {upcomingAppointments.length > 0 ? (
              <div className="space-y-4">
                {upcomingAppointments.map((apt, index) => (
                  <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <Clock className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{apt.type}</p>
                        <p className="text-sm text-muted-foreground">{apt.doctor}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{apt.date}</p>
                      <p className="text-sm text-muted-foreground">{apt.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum agendamento próximo</p>
                <Button className="mt-4" onClick={() => navigate('/portal/appointments/new')}>
                  Agendar Consulta
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-primary" />
              Notificações
            </CardTitle>
            <CardDescription>Atualizações importantes</CardDescription>
          </CardHeader>
          <CardContent>
            {notifications.length > 0 ? (
              <div className="space-y-3">
                {notifications.map((notification) => (
                  <div key={notification.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                    <Bell className={`h-5 w-5 mt-0.5 ${notification.type === 'alert' ? 'text-orange-500' : 'text-blue-500'}`} />
                    <p className="text-sm">{notification.message}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">
                <p>Você está em dia! Nenhuma notificação pendente.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Documents */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Documentos Recentes
            </CardTitle>
            <CardDescription>Seus últimos documentos e exames</CardDescription>
          </div>
          <Button variant="outline" onClick={() => navigate('/portal/my-records')}>
            Ver todos
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Nenhum documento recente</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
