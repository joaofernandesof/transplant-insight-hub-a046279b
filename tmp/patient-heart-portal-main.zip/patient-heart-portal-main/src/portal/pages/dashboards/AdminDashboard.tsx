import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Users, Calendar, DollarSign, TrendingUp, 
  Clock, FileText, ArrowRight, Activity
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePortalAuth } from '../../contexts/PortalAuthContext';

export default function AdminDashboard() {
  const { user } = usePortalAuth();
  const navigate = useNavigate();

  const stats = [
    { label: 'Pacientes Hoje', value: '12', icon: Users, color: 'text-blue-500', trend: '+2' },
    { label: 'Agendamentos', value: '24', icon: Calendar, color: 'text-green-500', trend: '+5' },
    { label: 'Faturamento (Mês)', value: 'R$ 45.000', icon: DollarSign, color: 'text-yellow-500', trend: '+12%' },
    { label: 'Taxa de Ocupação', value: '85%', icon: Activity, color: 'text-purple-500', trend: '+3%' },
  ];

  const quickActions = [
    { icon: Calendar, label: 'Nova Consulta', path: '/portal/appointments/new' },
    { icon: Users, label: 'Pacientes', path: '/portal/patients' },
    { icon: FileText, label: 'Prontuários', path: '/portal/medical-records' },
    { icon: DollarSign, label: 'Financeiro', path: '/portal/payments' },
  ];

  const todayAppointments = [
    { time: '08:00', patient: 'Maria Silva', type: 'Consulta', status: 'Confirmado' },
    { time: '09:30', patient: 'João Santos', type: 'Retorno', status: 'Aguardando' },
    { time: '11:00', patient: 'Ana Costa', type: 'Procedimento', status: 'Confirmado' },
    { time: '14:00', patient: 'Pedro Lima', type: 'Avaliação', status: 'Confirmado' },
  ];

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-6 text-primary-foreground">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
            <Activity className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-2xl font-bold mb-1">
              Olá, {user?.full_name?.split(' ')[0]}!
            </h1>
            <p className="opacity-90">Painel Administrativo - Portal Neo Folic</p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                  <p className="text-xs text-green-500">{stat.trend}</p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => (
          <Button
            key={action.label}
            variant="outline"
            className="h-auto py-4 flex flex-col items-center gap-2"
            onClick={() => navigate(action.path)}
          >
            <action.icon className="h-6 w-6" />
            <span>{action.label}</span>
          </Button>
        ))}
      </div>

      {/* Today's Schedule */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-primary" />
              Agenda de Hoje
            </CardTitle>
            <CardDescription>Consultas e procedimentos agendados</CardDescription>
          </div>
          <Button variant="outline" onClick={() => navigate('/portal/schedule')}>
            Ver Agenda Completa
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {todayAppointments.map((apt, index) => (
              <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                <div className="flex items-center gap-4">
                  <div className="text-lg font-bold text-primary">{apt.time}</div>
                  <div>
                    <p className="font-medium">{apt.patient}</p>
                    <p className="text-sm text-muted-foreground">{apt.type}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  apt.status === 'Confirmado' 
                    ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300' 
                    : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300'
                }`}>
                  {apt.status}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Secondary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
              <Users className="h-6 w-6 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">156</p>
              <p className="text-sm text-muted-foreground">Pacientes Ativos</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
              <TrendingUp className="h-6 w-6 text-green-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">23</p>
              <p className="text-sm text-muted-foreground">Novos este mês</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-yellow-100 dark:bg-yellow-900 flex items-center justify-center">
              <Calendar className="h-6 w-6 text-yellow-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">48</p>
              <p className="text-sm text-muted-foreground">Agend. Semana</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center">
              <FileText className="h-6 w-6 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">12</p>
              <p className="text-sm text-muted-foreground">Procedimentos</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
