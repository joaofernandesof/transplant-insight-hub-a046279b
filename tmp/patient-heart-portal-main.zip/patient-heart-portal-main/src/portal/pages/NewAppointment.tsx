import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { format, addDays, isSameDay, isAfter, isBefore, parseISO, addMinutes } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { 
  Calendar as CalendarIcon, Clock, ArrowLeft, ArrowRight, 
  Check, Loader2, AlertCircle 
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { usePortalAuth } from '../contexts/PortalAuthContext';
import { toast } from 'sonner';

interface AppointmentType {
  id: string;
  name: string;
  description: string;
  duration_minutes: number;
  color: string;
}

interface AvailableSlot {
  day_of_week: number;
  start_time: string;
  end_time: string;
}

interface TimeSlot {
  time: string;
  available: boolean;
}

export default function NewAppointment() {
  const navigate = useNavigate();
  const { user, session } = usePortalAuth();
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingSlots, setIsLoadingSlots] = useState(false);
  
  // Form state
  const [selectedType, setSelectedType] = useState<AppointmentType | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  
  // Data state
  const [appointmentTypes, setAppointmentTypes] = useState<AppointmentType[]>([]);
  const [availableSlots, setAvailableSlots] = useState<AvailableSlot[]>([]);
  const [blockedDates, setBlockedDates] = useState<Date[]>([]);
  const [existingAppointments, setExistingAppointments] = useState<{date: string; start_time: string; end_time: string}[]>([]);
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>([]);

  // Fetch initial data
  useEffect(() => {
    fetchAppointmentTypes();
    fetchAvailableSlots();
    fetchBlockedDates();
  }, []);

  // Generate time slots when date or type changes
  useEffect(() => {
    if (selectedDate && selectedType) {
      generateTimeSlots();
    }
  }, [selectedDate, selectedType, existingAppointments, availableSlots]);

  // Fetch existing appointments when date changes
  useEffect(() => {
    if (selectedDate) {
      fetchExistingAppointments(selectedDate);
    }
  }, [selectedDate]);

  const fetchAppointmentTypes = async () => {
    const { data, error } = await supabase
      .from('appointment_types')
      .select('*')
      .eq('is_active', true)
      .order('name');
    
    if (!error && data) {
      setAppointmentTypes(data);
    }
  };

  const fetchAvailableSlots = async () => {
    const { data, error } = await supabase
      .from('available_slots')
      .select('*')
      .eq('is_active', true);
    
    if (!error && data) {
      setAvailableSlots(data);
    }
  };

  const fetchBlockedDates = async () => {
    const { data, error } = await supabase
      .from('blocked_dates')
      .select('date');
    
    if (!error && data) {
      setBlockedDates(data.map(d => parseISO(d.date)));
    }
  };

  const fetchExistingAppointments = async (date: Date) => {
    setIsLoadingSlots(true);
    const dateStr = format(date, 'yyyy-MM-dd');
    
    const { data, error } = await supabase
      .from('appointments')
      .select('date, start_time, end_time')
      .eq('date', dateStr)
      .neq('status', 'cancelled');
    
    if (!error && data) {
      setExistingAppointments(data);
    }
    setIsLoadingSlots(false);
  };

  const generateTimeSlots = () => {
    if (!selectedDate || !selectedType) return;

    const dayOfWeek = selectedDate.getDay();
    const daySlots = availableSlots.filter(s => s.day_of_week === dayOfWeek);
    
    if (daySlots.length === 0) {
      setTimeSlots([]);
      return;
    }

    const slots: TimeSlot[] = [];
    const duration = selectedType.duration_minutes;
    const today = new Date();
    const isToday = isSameDay(selectedDate, today);

    daySlots.forEach(daySlot => {
      const [startHour, startMinute] = daySlot.start_time.split(':').map(Number);
      const [endHour, endMinute] = daySlot.end_time.split(':').map(Number);
      
      let currentTime = new Date(selectedDate);
      currentTime.setHours(startHour, startMinute, 0, 0);
      
      const endTime = new Date(selectedDate);
      endTime.setHours(endHour, endMinute, 0, 0);

      while (addMinutes(currentTime, duration) <= endTime) {
        const timeStr = format(currentTime, 'HH:mm');
        const slotEndTime = format(addMinutes(currentTime, duration), 'HH:mm');
        
        // Check if slot is in the past (for today)
        const isPast = isToday && isBefore(currentTime, today);
        
        // Check if slot conflicts with existing appointments
        const hasConflict = existingAppointments.some(apt => {
          const aptStart = apt.start_time.substring(0, 5);
          const aptEnd = apt.end_time.substring(0, 5);
          return (timeStr >= aptStart && timeStr < aptEnd) || 
                 (slotEndTime > aptStart && slotEndTime <= aptEnd) ||
                 (timeStr <= aptStart && slotEndTime >= aptEnd);
        });

        slots.push({
          time: timeStr,
          available: !isPast && !hasConflict
        });

        currentTime = addMinutes(currentTime, 30); // 30 min intervals
      }
    });

    setTimeSlots(slots);
  };

  const isDateDisabled = (date: Date) => {
    // Past dates
    if (isBefore(date, addDays(new Date(), -1))) return true;
    
    // More than 60 days in the future
    if (isAfter(date, addDays(new Date(), 60))) return true;
    
    // Blocked dates
    if (blockedDates.some(d => isSameDay(d, date))) return true;
    
    // Days without available slots
    const dayOfWeek = date.getDay();
    if (!availableSlots.some(s => s.day_of_week === dayOfWeek)) return true;
    
    return false;
  };

  const handleSubmit = async () => {
    if (!selectedType || !selectedDate || !selectedTime || !user || !session) return;

    setIsLoading(true);
    
    const [hours, minutes] = selectedTime.split(':').map(Number);
    const endTime = format(addMinutes(new Date().setHours(hours, minutes), selectedType.duration_minutes), 'HH:mm');

    const { error } = await supabase
      .from('appointments')
      .insert({
        user_id: session.user.id,
        appointment_type_id: selectedType.id,
        date: format(selectedDate, 'yyyy-MM-dd'),
        start_time: selectedTime,
        end_time: endTime,
        notes: notes.trim() || null,
        status: 'scheduled'
      });

    setIsLoading(false);

    if (error) {
      console.error('Error creating appointment:', error);
      toast.error('Erro ao agendar consulta. Tente novamente.');
      return;
    }

    toast.success('Consulta agendada com sucesso!');
    navigate('/portal/appointments');
  };

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate('/portal')}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Novo Agendamento</h1>
          <p className="text-muted-foreground">Escolha o tipo, data e horário da sua consulta</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-8">
        {[1, 2, 3, 4].map((s) => (
          <React.Fragment key={s}>
            <div 
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center font-medium transition-colors",
                step >= s 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted text-muted-foreground"
              )}
            >
              {step > s ? <Check className="h-5 w-5" /> : s}
            </div>
            {s < 4 && (
              <div className={cn(
                "w-12 h-1 mx-1",
                step > s ? "bg-primary" : "bg-muted"
              )} />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1: Select Type */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Tipo de Consulta</CardTitle>
            <CardDescription>Selecione o tipo de atendimento desejado</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            {appointmentTypes.map((type) => (
              <Button
                key={type.id}
                variant={selectedType?.id === type.id ? "default" : "outline"}
                className={cn(
                  "h-auto p-4 justify-start text-left",
                  selectedType?.id === type.id && "ring-2 ring-primary"
                )}
                onClick={() => setSelectedType(type)}
              >
                <div 
                  className="w-4 h-4 rounded-full mr-4 flex-shrink-0"
                  style={{ backgroundColor: type.color }}
                />
                <div className="flex-1">
                  <p className="font-medium">{type.name}</p>
                  <p className="text-sm opacity-80">{type.description}</p>
                  <p className="text-xs opacity-60 mt-1">
                    Duração: {type.duration_minutes} minutos
                  </p>
                </div>
              </Button>
            ))}

            <div className="flex justify-end mt-4">
              <Button 
                onClick={() => setStep(2)} 
                disabled={!selectedType}
              >
                Próximo
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Select Date */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Escolha a Data
            </CardTitle>
            <CardDescription>Selecione uma data disponível</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => {
                setSelectedDate(date);
                setSelectedTime(null);
              }}
              disabled={isDateDisabled}
              locale={ptBR}
              className="rounded-md border pointer-events-auto"
            />
          </CardContent>
          <CardContent className="flex justify-between border-t pt-4">
            <Button variant="outline" onClick={() => setStep(1)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <Button 
              onClick={() => setStep(3)} 
              disabled={!selectedDate}
            >
              Próximo
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Select Time */}
      {step === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Escolha o Horário
            </CardTitle>
            <CardDescription>
              Horários disponíveis para {selectedDate && format(selectedDate, "dd 'de' MMMM", { locale: ptBR })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingSlots ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : timeSlots.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Não há horários disponíveis nesta data.</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => setStep(2)}
                >
                  Escolher outra data
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                {timeSlots.map((slot) => (
                  <Button
                    key={slot.time}
                    variant={selectedTime === slot.time ? "default" : "outline"}
                    disabled={!slot.available}
                    onClick={() => setSelectedTime(slot.time)}
                    className={cn(
                      "h-12",
                      !slot.available && "opacity-50 cursor-not-allowed"
                    )}
                  >
                    {slot.time}
                  </Button>
                ))}
              </div>
            )}
          </CardContent>
          <CardContent className="flex justify-between border-t pt-4">
            <Button variant="outline" onClick={() => setStep(2)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <Button 
              onClick={() => setStep(4)} 
              disabled={!selectedTime}
            >
              Próximo
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Step 4: Confirmation */}
      {step === 4 && selectedType && selectedDate && selectedTime && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Check className="h-5 w-5" />
              Confirmar Agendamento
            </CardTitle>
            <CardDescription>Revise os dados e confirme sua consulta</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Tipo:</span>
                <span className="font-medium">{selectedType.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Data:</span>
                <span className="font-medium">
                  {format(selectedDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Horário:</span>
                <span className="font-medium">{selectedTime}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Duração:</span>
                <span className="font-medium">{selectedType.duration_minutes} minutos</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Observações (opcional)</Label>
              <Textarea
                id="notes"
                placeholder="Alguma informação adicional para a clínica..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
              />
            </div>
          </CardContent>
          <CardContent className="flex justify-between border-t pt-4">
            <Button variant="outline" onClick={() => setStep(3)}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Agendando...
                </>
              ) : (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  Confirmar Agendamento
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
