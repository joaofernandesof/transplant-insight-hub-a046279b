import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export type AppRole = 'admin' | 'doctor' | 'reception' | 'financial' | 'inventory' | 'patient';

export interface PortalUser {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  phone?: string;
  cpf?: string;
  birth_date?: string;
  address_street?: string;
  address_number?: string;
  address_complement?: string;
  address_neighborhood?: string;
  address_city?: string;
  address_state?: string;
  address_zip?: string;
  avatar_url?: string;
  roles: AppRole[];
  isPatient: boolean;
}

interface SignupData {
  email: string;
  password: string;
  full_name: string;
  phone?: string;
  cpf?: string;
}

interface PortalAuthContextType {
  user: PortalUser | null;
  session: Session | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (data: SignupData) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const PortalAuthContext = createContext<PortalAuthContextType | undefined>(undefined);

export function PortalAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<PortalUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchPortalUser = async (userId: string): Promise<PortalUser | null> => {
    try {
      const { data: portalUser, error: userError } = await supabase
        .from('portal_users')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (userError || !portalUser) return null;

      const { data: rolesData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId);

      const roles = (rolesData?.map(r => r.role) || ['patient']) as AppRole[];
      const isPatient = roles.includes('patient') && roles.length === 1;

      return {
        ...portalUser,
        roles,
        isPatient,
      };
    } catch (error) {
      console.error('Error fetching portal user:', error);
      return null;
    }
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      setSession(session);

      if (session?.user) {
        const portalUser = await fetchPortalUser(session.user.id);

        // If the auth session exists but the portal profile doesn't, force sign-out
        // to avoid redirect loops.
        if (!portalUser) {
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          setIsLoading(false);
          return;
        }

        setUser(portalUser);
      } else {
        setUser(null);
      }

      setIsLoading(false);
    });

    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setSession(session);

      if (session?.user) {
        const portalUser = await fetchPortalUser(session.user.id);
        if (!portalUser) {
          await supabase.auth.signOut();
          setSession(null);
          setUser(null);
          setIsLoading(false);
          return;
        }
        setUser(portalUser);
      }

      setIsLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });

      if (error) {
        return { success: false, error: error.message };
      }

      // Ensure session is in sync immediately (avoids redirect flicker)
      setSession(data.session ?? null);

      if (data.user) {
        const portalUser = await fetchPortalUser(data.user.id);
        if (!portalUser) {
          await supabase.auth.signOut();
          setSession(null);
          return { success: false, error: 'Usuário não cadastrado no Portal Neo Folic' };
        }
        setUser(portalUser);
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (data: SignupData) => {
    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          emailRedirectTo: window.location.origin + '/portal',
          data: {
            full_name: data.full_name,
          },
        },
      });

      if (authError) {
        return { success: false, error: authError.message };
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  };

  const refreshUser = async () => {
    if (session?.user) {
      const portalUser = await fetchPortalUser(session.user.id);
      setUser(portalUser);
    }
  };

  return (
    <PortalAuthContext.Provider value={{ user, session, isLoading, login, signup, logout, refreshUser }}>
      {children}
    </PortalAuthContext.Provider>
  );
}

export function usePortalAuth() {
  const context = useContext(PortalAuthContext);
  if (context === undefined) {
    throw new Error('usePortalAuth must be used within a PortalAuthProvider');
  }
  return context;
}
