import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { PortalAuthProvider, usePortalAuth } from './contexts/PortalAuthContext';
import { PortalSidebar } from './components/PortalSidebar';
import PortalLanding from './pages/PortalLanding';
import PortalLogin from './pages/PortalLogin';
import PortalRegister from './pages/PortalRegister';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import PortalHome from './pages/PortalHome';
import PortalSettings from './pages/PortalSettings';
import NewAppointment from './pages/NewAppointment';
import MyAppointments from './pages/MyAppointments';
import PlaceholderPage from './pages/PlaceholderPage';
import AuthDiagnostic from './pages/AuthDiagnostic';
import { Loader2 } from 'lucide-react';

// Protected route wrapper
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = usePortalAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/portal/login" replace />;
  }

  return <PortalSidebar>{children}</PortalSidebar>;
}

// Index route: when authenticated, go to the dashboard; otherwise, show landing.
function PortalIndexRoute() {
  const { session, user, isLoading } = usePortalAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Not authenticated → show public landing.
  if (!session) {
    return <Navigate to="/portal/landing" replace />;
  }

  // Authenticated but portal user still being loaded → keep waiting.
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <PortalHome />
    </ProtectedRoute>
  );
}

function PortalRoutes() {
  return (
    <Routes>
      {/* Index */}
      <Route index element={<PortalIndexRoute />} />

      {/* Public routes */}
      <Route path="landing" element={<PortalLanding />} />
      <Route path="login" element={<PortalLogin />} />
      <Route path="register" element={<PortalRegister />} />
      <Route path="forgot-password" element={<ForgotPassword />} />
      <Route path="reset-password" element={<ResetPassword />} />
      <Route path="auth-diagnostic" element={<AuthDiagnostic />} />

      {/* Protected routes */}
      <Route path="settings" element={<ProtectedRoute><PortalSettings /></ProtectedRoute>} />

      {/* Patient routes */}
      <Route path="appointments" element={<ProtectedRoute><MyAppointments /></ProtectedRoute>} />
      <Route path="appointments/new" element={<ProtectedRoute><NewAppointment /></ProtectedRoute>} />
      <Route path="my-records" element={<ProtectedRoute><PlaceholderPage title="Meus Documentos" /></ProtectedRoute>} />
      <Route path="orientations" element={<ProtectedRoute><PlaceholderPage title="Orientações" /></ProtectedRoute>} />
      <Route path="news" element={<ProtectedRoute><PlaceholderPage title="Notícias" /></ProtectedRoute>} />

      {/* Scheduling */}
      <Route path="schedule" element={<ProtectedRoute><PlaceholderPage title="Agenda" /></ProtectedRoute>} />
      <Route path="waiting-room" element={<ProtectedRoute><PlaceholderPage title="Sala de Espera" /></ProtectedRoute>} />
      <Route path="rooms" element={<ProtectedRoute><PlaceholderPage title="Salas" /></ProtectedRoute>} />

      {/* Medical */}
      <Route path="patients" element={<ProtectedRoute><PlaceholderPage title="Pacientes" /></ProtectedRoute>} />
      <Route path="medical-records" element={<ProtectedRoute><PlaceholderPage title="Prontuários" /></ProtectedRoute>} />
      <Route path="templates" element={<ProtectedRoute><PlaceholderPage title="Modelos" /></ProtectedRoute>} />
      <Route path="teleconsultation" element={<ProtectedRoute><PlaceholderPage title="Teleconsulta" /></ProtectedRoute>} />

      {/* Financial */}
      <Route path="payments" element={<ProtectedRoute><PlaceholderPage title="Pagamentos" /></ProtectedRoute>} />
      <Route path="invoices" element={<ProtectedRoute><PlaceholderPage title="Notas Fiscais" /></ProtectedRoute>} />
      <Route path="reports/financial" element={<ProtectedRoute><PlaceholderPage title="Relatórios Financeiros" /></ProtectedRoute>} />

      {/* Inventory */}
      <Route path="inventory/items" element={<ProtectedRoute><PlaceholderPage title="Itens do Estoque" /></ProtectedRoute>} />
      <Route path="inventory/movements" element={<ProtectedRoute><PlaceholderPage title="Movimentações" /></ProtectedRoute>} />
      <Route path="inventory/suppliers" element={<ProtectedRoute><PlaceholderPage title="Fornecedores" /></ProtectedRoute>} />

      {/* Communication */}
      <Route path="whatsapp" element={<ProtectedRoute><PlaceholderPage title="WhatsApp" /></ProtectedRoute>} />
      <Route path="campaigns" element={<ProtectedRoute><PlaceholderPage title="Campanhas" /></ProtectedRoute>} />

      {/* Surveys */}
      <Route path="nps" element={<ProtectedRoute><PlaceholderPage title="NPS" /></ProtectedRoute>} />
      <Route path="surveys" element={<ProtectedRoute><PlaceholderPage title="Pesquisas" /></ProtectedRoute>} />

      {/* Reports */}
      <Route path="reports" element={<ProtectedRoute><PlaceholderPage title="Relatórios" /></ProtectedRoute>} />

      {/* Admin */}
      <Route path="admin/users" element={<ProtectedRoute><PlaceholderPage title="Usuários" /></ProtectedRoute>} />
      <Route path="admin/settings" element={<ProtectedRoute><PlaceholderPage title="Configurações do Sistema" /></ProtectedRoute>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/portal/landing" replace />} />
    </Routes>
  );
}

export default function PortalApp() {
  return (
    <PortalAuthProvider>
      <PortalRoutes />
    </PortalAuthProvider>
  );
}
